﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhonemeIdentifier {
	class Program {
		static void Main(string[] args) {
			//https://www.phon.ucl.ac.uk/home/wells/ipa-unicode.htm
			string[] vowelNames = new string[] { "i", "ɪ", "e", "ɛ", "æ", "ɨ", "ə", "ʌ", "a", "ɑ", "u", "o", "ʊ" };
			string[] consonantNames = new string[] { "p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "θ", "ð", "ʃ", "ʒ", "ʧ", "ʤ", "m", "n", "ŋ", "l", "ɹ", "j", "w", "ʍ", "h", "ʔ" };
			string[] phonemes = args;
			if(phonemes.All(phoneme => vowelNames.Contains(phoneme))) FindVowelDescriptions(phonemes, vowelNames);
			else if(phonemes.All(phoneme => consonantNames.Contains(phoneme))) FindConsonantDescriptions(phonemes, consonantNames);
			else Console.WriteLine("Either the phonemes were not entered correctly or were not all from the same table.  Visit https://www.phon.ucl.ac.uk/home/wells/ipa-unicode.htm for correct unicode representations");

			while(true) ;
		}

		public static void FindVowelDescriptions(string[] phonemes, string[] vowelNames) {
			int vowelFeatureCount = 9;
			bool[][] vowelTable = new bool[][] {
				new bool[] { false, true, true, false, true, false, true, false, true },//features for "i"
				new bool[] { false, true, true, false, true, false, true, false, false },//features for "ɪ"
				new bool[] { false, true, true, false, false, false, true, false, true },//features for "e"
				new bool[] { false, true, true, false, false, false, true, false, false },//features for "ɛ"
				new bool[] { false, true, true, false, false, false, true, true, false },//features for "æ"
				new bool[] { false, true, true, false, true, false, false, false, false },//features for "ɨ"
				new bool[] { false, true, true, false, false, false, false, false, false },//features for "ə"
				new bool[] { false, true, true, false, false, true, false, false, false },//features for "ʌ"
				new bool[] { false, true, true, false, false, true, false, true, true },//features for "a"
				new bool[] { false, true, true, false, false, true, false, true, true },//features for "ɑ"
				new bool[] { false, true, true, true, true, true, false, false, true },//features for "u"
				new bool[] { false, true, true, true, false, true, false, false, true },//features for "o"
				new bool[] { false, true, true, true, true, true, false, false, false }//features for "ʊ"
			};
			var phonemeArrays = phonemes.Select(phoneme => vowelTable[Array.IndexOf(vowelNames, phoneme)]).ToArray();
			//create an array of features that maximally covers the similarities in the set of phonemes
			//so if every phoneme in the set is minus or plus for some feature, then put a minus or plus in the maximal array
			//otherwise put a wildcard
			//so by index, see if every array in phonemeArrays matches the first array's value
			FeatureValue[] maximalDescription = Enumerable.Range(0, vowelFeatureCount).ToArray().Select(index => phonemeArrays.All((features) => features[index] == phonemeArrays[0][index]) switch {
				false => FeatureValue.Wildcard,
				true => phonemeArrays[0][index] ? FeatureValue.Plus : FeatureValue.Minus
			}).ToArray();
			Console.WriteLine($"Set of phonemes given: {String.Join(", ", phonemes)}");
			Console.WriteLine($"This set of phonemes is maximally described by {DescriptionToString(maximalDescription)}");
			//sometimes, the maximal set may not actually 
			if(!IdentifiesUniquely(maximalDescription, phonemes)) {
				Console.WriteLine("This set of phonemes cannot be uniquely identified");
				return;
			}
			//starting with the maximal description, we want to generate leads by taking each definite feature and making it a wildcard,
			//and checking that it still uniquely identifies the set of phonemes

			Queue<FeatureValue[]> leads = new Queue<FeatureValue[]>();
			List<FeatureValue[]> minimalDescriptions = new List<FeatureValue[]>();
			HashSet<string> discoveredDescriptions = new HashSet<string>();//every description we've looked at thus far
			var minDescSet = new HashSet<string>();
			leads.Enqueue(maximalDescription);

			while(leads.Count > 0) {
				var lead = leads.Dequeue();
				var slead = DescriptionToString(lead);
				if(discoveredDescriptions.Contains(slead)) continue;
				discoveredDescriptions.Add(slead);
				var newLeads = Enumerable.Range(0, vowelFeatureCount).ToArray().Select(featureIndex => lead[featureIndex].id switch {
					2 => null,//if there's already a wildcard at featureIndex, there's no definite feature that can be made a wildcard
					_ => lead.Select((value, index) => featureIndex == index ? FeatureValue.Wildcard : value)//this copies the array with the one index changed
				}).Where(clead => clead != null && IdentifiesUniquely(clead.ToArray(), phonemes));//this cuts out empty leads and leads that don't uniquely identify the phoneme set

				if(newLeads.Count() == 0 && !minDescSet.Contains(slead)) {
					minDescSet.Add(slead);
					//Console.WriteLine(slead);
				} else foreach(var newLead in newLeads) leads.Enqueue(newLead.ToArray());
			}

			Console.WriteLine($"There are {minDescSet.Count} minimal descriptions of the phonemes given:");
			foreach(var minDesc in minDescSet) Console.WriteLine(minDesc);

			bool IdentifiesUniquely(FeatureValue[] description, string[] phonemeSet) {
				//true if the description matches the phonemes and no others
				int matches = 0;
				foreach(string phoneme in phonemeSet) {//check if the description matches the given phonemes
					var features = vowelTable[Array.IndexOf(vowelNames, phoneme)];
					for(int i = 0; i < vowelFeatureCount; i++) if(!description[i].Matches(features[i])) return false;//non match was found
				}
				for(int i = 0; i < vowelNames.Length; i++) {
					if(DescriptionMatchesPhonemeFeatures(description, vowelNames[i])) matches++;
				}
				return matches == phonemeSet.Length;
			}

			bool DescriptionMatchesPhonemeFeatures(FeatureValue[] description, string phoneme) {
				var features = vowelTable[Array.IndexOf(vowelNames, phoneme)];
				return description.Zip(features).Select(zipped => zipped.First.Matches(zipped.Second)).All(b => b);
			}
		}

		public static void FindConsonantDescriptions(string[] phonemes, string[] consonantNames) {
			int consonantFeatureCount = 12;
			bool[][] consonantTable = new bool[][] {
				new bool[] { true, false, false, false, true, false, true, false, false, true, false, false },
				new bool[] { true, false, false, true, true, false, true, false, false, true, false, false },
				new bool[] { true, false, false, false, false, true, true, false, false, true, false, false },
				new bool[] { true, false, false, true, false, true, true, false, false, true, false, false },
				new bool[] { true, false, false, false, false, false, false, false, false, true, true, false },
				new bool[] { true, false, false, true, false, false, false, false, false, true, true, false },
				new bool[] { true, false, false, false, true, false, true, false, false, false, false, false },
				new bool[] { true, false, false, true, true, false, true, false, false, false, false, false },
				new bool[] { true, false, false, false, false, true, true, true, false, false, false, false },
				new bool[] { true, false, false, true, false, true, true, true, false, false, false, false },
				new bool[] { true, false, false, false, false, true, true, false, false, false, false, false },
				new bool[] { true, false, false, true, false, true, true, false, false, false, false, false },
				new bool[] { true, false, false, false, false, true, false, true, false, false, false, false },
				new bool[] { true, false, false, true, false, true, false, true, false, false, false, false },
				new bool[] { true, false, false, false, false, true, false, true, false, true, false, false },
				new bool[] { true, false, false, true, false, true, false, true, false, true, false, false },
				new bool[] { true, false, true, true, true, false, true, false, true, true, false, false },
				new bool[] { true, false, true, true, false, true, true, false, true, true, false, false },
				new bool[] { true, false, true, true, false, false, false, false, true, true, true, false },
				new bool[] { true, false, true, true, false, true, true, false, false, false, false, true },
				new bool[] { true, false, true, true, false, true, true, false, false, false, false, false },
				new bool[] { false, false, true, true, false, false, false, false, false, false, false, false },
				new bool[] { false, false, true, true, true, false, false, false, false, false, false, false },
				new bool[] { false, false, false, false, true, false, false, false, false, false, false, false },
				new bool[] { false, false, false, false, false, false, false, false, false, false, true, false },
				new bool[] { false, false, false, false, false, false, false, false, false, true, true, false }
			};

			var phonemeArrays = phonemes.Select(phoneme => consonantTable[Array.IndexOf(consonantNames, phoneme)]).ToArray();
			//create an array of features that maximally covers the similarities in the set of phonemes
			//so if every phoneme in the set is minus or plus for some feature, then put a minus or plus in the maximal array
			//otherwise put a wildcard
			//so by index, see if every array in phonemeArrays matches the first array's value
			FeatureValue[] maximalDescription = Enumerable.Range(0, consonantFeatureCount).ToArray().Select(index => phonemeArrays.All((features) => features[index] == phonemeArrays[0][index]) switch {
				false => FeatureValue.Wildcard,
				true => phonemeArrays[0][index] ? FeatureValue.Plus : FeatureValue.Minus
			}).ToArray();
			Console.WriteLine($"Set of phonemes given: {String.Join(", ", phonemes)}");
			Console.WriteLine($"This set of phonemes is maximally described by {DescriptionToString(maximalDescription)}");
			//sometimes, the maximal set may not actually 
			if(!IdentifiesUniquely(maximalDescription, phonemes)) {
				Console.WriteLine("This set of phonemes cannot be uniquely identified");
				return;
			}
			//starting with the maximal description, we want to generate leads by taking each definite feature and making it a wildcard,
			//and checking that it still uniquely identifies the set of phonemes

			Queue<FeatureValue[]> leads = new Queue<FeatureValue[]>();
			List<FeatureValue[]> minimalDescriptions = new List<FeatureValue[]>();
			HashSet<string> discoveredDescriptions = new HashSet<string>();//every description we've looked at thus far
			var minDescSet = new HashSet<string>();
			leads.Enqueue(maximalDescription);

			while(leads.Count > 0) {
				var lead = leads.Dequeue();
				var slead = DescriptionToString(lead);
				if(discoveredDescriptions.Contains(slead)) continue;
				discoveredDescriptions.Add(slead);
				var newLeads = Enumerable.Range(0, consonantFeatureCount).ToArray().Select(featureIndex => lead[featureIndex].id switch {
					2 => null,//if there's already a wildcard at featureIndex, there's no definite feature that can be made a wildcard
					_ => lead.Select((value, index) => featureIndex == index ? FeatureValue.Wildcard : value)//this copies the array with the one index changed
				}).Where(clead => clead != null && IdentifiesUniquely(clead.ToArray(), phonemes));//this cuts out empty leads and leads that don't uniquely identify the phoneme set
				
				if(newLeads.Count() == 0 && !minDescSet.Contains(slead)) {
					minDescSet.Add(slead);
					//Console.WriteLine(slead);
				} else foreach(var newLead in newLeads) leads.Enqueue(newLead.ToArray());
			}
			//var minDescSet = new HashSet<string>(minimalDescriptions.Select(desc => DescriptionToString(desc)));
			Console.WriteLine($"There are {minDescSet.Count} minimal descriptions of the phonemes given:");
			foreach(var minDesc in minDescSet) Console.WriteLine(minDesc);

			bool IdentifiesUniquely(FeatureValue[] description, string[] phonemeSet) {
				//true if the description matches the phonemes and no others
				int matches = 0;
				foreach(string phoneme in phonemeSet) {//check if the description matches the given phonemes
					var features = consonantTable[Array.IndexOf(consonantNames, phoneme)];
					for(int i = 0; i < consonantFeatureCount; i++) if(!description[i].Matches(features[i])) return false;//non match was found
				}
				for(int i = 0; i < consonantNames.Length; i++) {
					if(DescriptionMatchesPhonemeFeatures(description, consonantNames[i])) matches++;
				}
				return matches == phonemeSet.Length;
			}

			bool DescriptionMatchesPhonemeFeatures(FeatureValue[] description, string phoneme) {
				var features = consonantTable[Array.IndexOf(consonantNames, phoneme)];
				return description.Zip(features).Select(zipped => zipped.First.Matches(zipped.Second)).All(b => b);
			}
		}

		private static string DescriptionToString(FeatureValue[] description) => String.Join(", ", description.Select(fvalue => fvalue.ToString()));
	}
}
